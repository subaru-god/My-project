#include <windows.h>
#include <vector>
#include <cmath>
#include <fstream>

// �Ֆʒ�`
const int BOARD_SIZE = 8;
const int CELL_SIZE = 50;
const int OFFSET_X = 40;
const int OFFSET_Y = 40;
const int PANEL_HEIGHT = 60; // �����X�e�[�^�X�p

int board[BOARD_SIZE][BOARD_SIZE] = { 0 };
int currentTurn = 1; // 1: �l��(��), 2: AI(��)
bool isGameOver = false;

// AI���x�� (1: ����=�����_��, 2: ����=�����D��, 3: �㋉=�]���֐�)
int aiLevel = 3; 

// �ǉ��w�K�p�F����̑΋Ǘ�����ۑ�����\����
struct HistoryRecord {
    int boardState[BOARD_SIZE][BOARD_SIZE];
    int moveX;
    int moveY;
    int player;
};
std::vector<HistoryRecord> gameHistory;

// 8�����̈ړ��x�N�g��
const int dx[8] = { 0, 0, -1, 1, -1, 1, -1, 1 };
const int dy[8] = { -1, 1, 0, 0, -1, -1, 1, 1 };

// �w�肵���}�X�ɐ΂�u�����Ƃ��A���Ԃ��鑊��̐΂̃��X�g���擾
std::vector<POINT> GetFlipDiscs(int x, int y, int player) {
    std::vector<POINT> flips;
    if (x < 0 || x >= BOARD_SIZE || y < 0 || y >= BOARD_SIZE) return flips;
    if (board[y][x] != 0) return flips;

    int opponent = (player == 1) ? 2 : 1;

    for (int i = 0; i < 8; i++) {
        int nx = x + dx[i];
        int ny = y + dy[i];
        std::vector<POINT> temp;

        while (nx >= 0 && nx < BOARD_SIZE && ny >= 0 && ny < BOARD_SIZE && board[ny][nx] == opponent) {
            POINT pt = { nx, ny };
            temp.push_back(pt);
            nx += dx[i];
            ny += dy[i];
        }

        if (nx >= 0 && nx < BOARD_SIZE && ny >= 0 && ny < BOARD_SIZE && board[ny][nx] == player) {
            flips.insert(flips.end(), temp.begin(), temp.end());
        }
    }
    return flips;
}

// �w��v���C���[���ǂ����ɐ΂�u���邩����
bool CanMove(int player) {
    for (int y = 0; y < BOARD_SIZE; y++) {
        for (int x = 0; x < BOARD_SIZE; x++) {
            if (!GetFlipDiscs(x, y, player).empty()) {
                return true;
            }
        }
    }
    return false;
}

// �Q�[��������
void InitGame() {
    for (int y = 0; y < BOARD_SIZE; y++) {
        for (int x = 0; x < BOARD_SIZE; x++) {
            board[y][x] = 0;
        }
    }
    board[3][3] = 2; board[3][4] = 1;
    board[4][3] = 1; board[4][4] = 2;
    currentTurn = 1;
    isGameOver = false;
    gameHistory.clear();
}

// �����i�ǉ��w�K�f�[�^�j���t�@�C���ɕۑ�����֐�
void SaveHistoryToFile() {
    std::ofstream file("othello_history.txt", std::ios::app);
    if (!file.is_open()) return;

    file << "=== NEW GAME (AI Level: " << aiLevel << ") ===\n";
    for (const auto& h : gameHistory) {
        file << "Player: " << h.player << " Move:(" << h.moveX << "," << h.moveY << ")\n";
    }
    file.close();
}

// AI�̎w���茈��i���x���ɉ������v�l�j
POINT GetAIBestMove(int aiPlayer) {
    std::vector<POINT> validMoves;
    for (int y = 0; y < BOARD_SIZE; y++) {
        for (int x = 0; x < BOARD_SIZE; x++) {
            if (!GetFlipDiscs(x, y, aiPlayer).empty()) {
                POINT pt = { x, y };
                validMoves.push_back(pt);
            }
        }
    }

    if (validMoves.empty()) return { -1, -1 };

    // ���x��1: �����_��
    if (aiLevel == 1) {
        int idx = rand() % validMoves.size();
        return validMoves[idx];
    }

    // ���x��2: �ł��������Ԃ�����I��
    if (aiLevel == 2) {
        POINT bestMove = validMoves[0];
        size_t maxFlips = 0;
        for (const auto& move : validMoves) {
            auto flips = GetFlipDiscs(move.x, move.y, aiPlayer);
            if (flips.size() > maxFlips) {
                maxFlips = flips.size();
                bestMove = move;
            }
        }
        return bestMove;
    }

    // ���x��3: �㋉�i�p��ӂ��d������]���֐� + �I�����C��/ONNX���f���g���p�j
    // �p(0,0�Ȃ�)���ŗD�悵�AX�ł���C�ł��������d�ݕt��
    int weight[8][8] = {
        { 30, -12,  0,  0,  0,  0, -12,  30 },
        {-12, -15, -3, -3, -3, -3, -15, -12 },
        {  0,  -3,  0,  0,  0,  0,  -3,   0 },
        {  0,  -3,  0,  0,  0,  0,  -3,   0 },
        {  0,  -3,  0,  0,  0,  0,  -3,   0 },
        {  0,  -3,  0,  0,  0,  0,  -3,   0 },
        {-12, -15, -3, -3, -3, -3, -15, -12 },
        { 30, -12,  0,  0,  0,  0, -12,  30 }
    };

    POINT bestMove = validMoves[0];
    int maxScore = -9999;
    for (const auto& move : validMoves) {
        int score = weight[move.y][move.x];
        // ����ɗ��Ԃ��閇������������
        auto flips = GetFlipDiscs(move.x, move.y, aiPlayer);
        score += (int)flips.size();

        if (score > maxScore) {
            maxScore = score;
            bestMove = move;
        }
    }
    return bestMove;
}

// ��Ԃ̍X�V����
void AdvanceTurn(HWND hwnd) {
    int nextTurn = (currentTurn == 1) ? 2 : 1;

    if (CanMove(nextTurn)) {
        currentTurn = nextTurn;
    } else if (CanMove(currentTurn)) {
        MessageBoxA(hwnd, (nextTurn == 1) ? "���̓p�X�ł��B" : "���̓p�X�ł��B", "�p�X", MB_OK);
    } else {
        isGameOver = true;
        SaveHistoryToFile(); // �Q�[���I�����Ɋw�K�p�f�[�^��ۑ�

        int blackCount = 0, whiteCount = 0;
        for (int y = 0; y < BOARD_SIZE; y++) {
            for (int x = 0; x < BOARD_SIZE; x++) {
                if (board[y][x] == 1) blackCount++;
                if (board[y][x] == 2) whiteCount++;
            }
        }
        char msg[120];
        wsprintfA(msg, "�Q�[���I��!\n��(���Ȃ�): %d\n��(AI): %d\n\n(�w�K�f�[�^���L�^���܂���)", blackCount, whiteCount);
        MessageBoxA(hwnd, msg, "�΋ǌ���", MB_OK);
    }
}

// �E�B���h�E�v���V�[�W��
LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    switch (uMsg) {
    case WM_CREATE:
        InitGame();
        return 0;

    // �E�N���b�N��AI���x����ύX���郁�j���[��\��
    case WM_RBUTTONDOWN:
        {
            HMENU hMenu = CreatePopupMenu();
            AppendMenuA(hMenu, MF_STRING | (aiLevel == 1 ? MF_CHECKED : 0), 1, "AI���x�� 1: ���� (�����_��)");
            AppendMenuA(hMenu, MF_STRING | (aiLevel == 2 ? MF_CHECKED : 0), 2, "AI���x�� 2: ���� (�����D��)");
            AppendMenuA(hMenu, MF_STRING | (aiLevel == 3 ? MF_CHECKED : 0), 3, "AI���x�� 3: �㋉ (�헪�]��)");
            AppendMenuA(hMenu, MF_SEPARATOR, 0, NULL);
            AppendMenuA(hMenu, MF_STRING, 4, "�Q�[�������Z�b�g");

            POINT pt;
            GetCursorPos(&pt);
            TrackPopupMenu(hMenu, TPM_RIGHTBUTTON, pt.x, pt.y, 0, hwnd, NULL);
            DestroyMenu(hMenu);
        }
        return 0;

    case WM_COMMAND:
        {
            int id = LOWORD(wParam);
            if (id >= 1 && id <= 3) {
                aiLevel = id;
                char title[50];
                wsprintfA(title, "AI�I�Z���ΐ�A�v�� (AI���x��: %d)", aiLevel);
                SetWindowTextA(hwnd, title);
            } else if (id == 4) {
                InitGame();
                InvalidateRect(hwnd, NULL, TRUE);
            }
        }
        return 0;

    case WM_LBUTTONDOWN:
        {
            if (isGameOver) return 0;

            if (currentTurn == 1) {
                int mouseX = LOWORD(lParam);
                int mouseY = HIWORD(lParam);
                int bx = (mouseX - OFFSET_X) / CELL_SIZE;
                int by = (mouseY - OFFSET_Y) / CELL_SIZE;

                auto flips = GetFlipDiscs(bx, by, 1);
                if (!flips.empty()) {
                    // �����̋L�^ (�ǉ��w�K�p)
                    HistoryRecord record;
                    memcpy(record.boardState, board, sizeof(board));
                    record.moveX = bx;
                    record.moveY = by;
                    record.player = 1;
                    gameHistory.push_back(record);

                    // �΂�u��
                    board[by][bx] = 1;
                    for (const auto& pt : flips) {
                        board[pt.y][pt.x] = 1;
                    }
                    InvalidateRect(hwnd, NULL, TRUE);

                    AdvanceTurn(hwnd);
                    InvalidateRect(hwnd, NULL, TRUE);

                    // AI�̃^�[��
                    if (currentTurn == 2 && !isGameOver) {
                        POINT aiMove = GetAIBestMove(2);
                        if (aiMove.x != -1) {
                            auto aiFlips = GetFlipDiscs(aiMove.x, aiMove.y, 2);
                            
                            HistoryRecord aiRecord;
                            memcpy(aiRecord.boardState, board, sizeof(board));
                            aiRecord.moveX = aiMove.x;
                            aiRecord.moveY = aiMove.y;
                            aiRecord.player = 2;
                            gameHistory.push_back(aiRecord);

                            board[aiMove.y][aiMove.x] = 2;
                            for (const auto& pt : aiFlips) {
                                board[pt.y][pt.x] = 2;
                            }
                        }
                        AdvanceTurn(hwnd);
                        InvalidateRect(hwnd, NULL, TRUE);
                    }
                }
            }
        }
        return 0;

    case WM_PAINT:
        {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hwnd, &ps);

            // �w�i�i�{�[�h�̗ΐF�j
            HBRUSH hGreen = CreateSolidBrush(RGB(0, 128, 0));
            HBRUSH hOldBrush = (HBRUSH)SelectObject(hdc, hGreen);
            Rectangle(hdc, OFFSET_X, OFFSET_Y, OFFSET_X + BOARD_SIZE * CELL_SIZE, OFFSET_Y + BOARD_SIZE * CELL_SIZE);
            SelectObject(hdc, hOldBrush);
            DeleteObject(hGreen);

            // �i�q��
            HPEN hPen = CreatePen(PS_SOLID, 1, RGB(0, 0, 0));
            HPEN hOldPen = (HPEN)SelectObject(hdc, hPen);
            for (int i = 0; i <= BOARD_SIZE; i++) {
                MoveToEx(hdc, OFFSET_X + i * CELL_SIZE, OFFSET_Y, NULL);
                LineTo(hdc, OFFSET_X + i * CELL_SIZE, OFFSET_Y + BOARD_SIZE * CELL_SIZE);
                MoveToEx(hdc, OFFSET_X, OFFSET_Y + i * CELL_SIZE, NULL);
                LineTo(hdc, OFFSET_X + BOARD_SIZE * CELL_SIZE, OFFSET_Y + i * CELL_SIZE);
            }

            // �y�T�|�[�g�@�\�z�l�ԁi���^�[���j���u����ꏊ�ɔ����h�b�g��\��
            if (currentTurn == 1 && !isGameOver) {
                HBRUSH hHintBrush = CreateSolidBrush(RGB(0, 100, 0));
                SelectObject(hdc, hHintBrush);
                HPEN hNullPen = (HPEN)GetStockObject(NULL_PEN);
                SelectObject(hdc, hNullPen);

                for (int y = 0; y < BOARD_SIZE; y++) {
                    for (int x = 0; x < BOARD_SIZE; x++) {
                        if (!GetFlipDiscs(x, y, 1).empty()) {
                            int cx = OFFSET_X + x * CELL_SIZE;
                            int cy = OFFSET_Y + y * CELL_SIZE;
                            Ellipse(hdc, cx + 18, cy + 18, cx + CELL_SIZE - 18, cy + CELL_SIZE - 18);
                        }
                    }
                }
                DeleteObject(hHintBrush);
            }

            SelectObject(hdc, hOldPen);
            DeleteObject(hPen);

            // �΂̕`��
            for (int y = 0; y < BOARD_SIZE; y++) {
                for (int x = 0; x < BOARD_SIZE; x++) {
                    int cx = OFFSET_X + x * CELL_SIZE;
                    int cy = OFFSET_Y + y * CELL_SIZE;

                    if (board[y][x] == 1) {
                        HBRUSH hBlack = CreateSolidBrush(RGB(0, 0, 0));
                        SelectObject(hdc, hBlack);
                        Ellipse(hdc, cx + 4, cy + 4, cx + CELL_SIZE - 4, cy + CELL_SIZE - 4);
                        DeleteObject(hBlack);
                    } else if (board[y][x] == 2) {
                        HBRUSH hWhite = CreateSolidBrush(RGB(255, 255, 255));
                        SelectObject(hdc, hWhite);
                        Ellipse(hdc, cx + 4, cy + 4, cx + CELL_SIZE - 4, cy + CELL_SIZE - 4);
                        DeleteObject(hWhite);
                    }
                }
            }

            // �����X�e�[�^�X�i���݂̃^�[����AI���x���\���j
            SetBkMode(hdc, TRANSPARENT);
            char status[100];
            wsprintfA(status, "�^�[��: %s  |  [�E�N���b�N]��AI�ݒ�E���Z�b�g", (currentTurn == 1) ? "��(���Ȃ�)" : "��(AI�v�l��...)");
            TextOutA(hdc, OFFSET_X, OFFSET_Y + BOARD_SIZE * CELL_SIZE + 15, status, lstrlenA(status));

            EndPaint(hwnd, &ps);
        }
        return 0;

    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    const char* CLASS_NAME = "AI_Othello_Window_v2";

    WNDCLASSA wc = {};
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = CLASS_NAME;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);

    RegisterClassA(&wc);

    // �E�B���h�E�T�C�Y���X�e�[�^�X�������c���Ɋg�� (��490, ����570)
    HWND hwnd = CreateWindowExA(
        0, CLASS_NAME, "AI�I�Z���ΐ�A�v�� (AI���x��: 3)",
        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
        CW_USEDEFAULT, CW_USEDEFAULT, 490, 570,
        NULL, NULL, hInstance, NULL
    );

    if (hwnd == NULL) return 0;

    ShowWindow(hwnd, nCmdShow);

    MSG msg = {};
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return 0;
}